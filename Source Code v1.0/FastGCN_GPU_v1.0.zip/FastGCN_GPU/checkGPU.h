#ifndef CHECKGPU_H
#define CHECKGPU_H

#ifdef __cplusplus
   extern "C" {
#endif
size_t getFreeMemory();
void ckEnv();
int getGPUnum();
#ifdef __cplusplus
   }
#endif

#endif