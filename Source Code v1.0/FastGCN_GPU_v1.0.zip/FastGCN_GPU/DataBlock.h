#pragma once

#ifndef GENERALTYPE_H
	#include "generalType.h"
#endif
using namespace std;

class PDataBlock
{
public:
	PDataBlock(void);
	virtual ~PDataBlock(void);

	void readDataBlock(const char* path);	
	void printfResult(const char* path);	

public:	
	int		p_iSampleNum;
	int		p_iSnpNum;
	float	critical_val;// threshold of z-socre
	float	fdr_para;// fdr parameter
	float   remain_para; 
	int     out_count; // output the first out_count interactions of the result.
	vector<string>	p_SnpNames;
	float*	p_Data;
	float*  p_Result;
	float* pcc_coeff;

};
