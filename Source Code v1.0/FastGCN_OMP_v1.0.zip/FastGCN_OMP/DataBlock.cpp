#include "DataBlock.h"

#include <omp.h>

#define FILE_CACHE_SIZE 0x80000000 /* = 2GB */
#define FILE_VIEW_SIZE 0x40000000 /* = 1GB */
using namespace std;
//sort in ascend order
int comp(const void *a,const void *b){ return (*(geneInfo *)a).gene_entropy>(*(geneInfo *)b).gene_entropy?1:-1; }
//sort in ascend order
int comp_q_ascend(const void *a,const void *b){ return (*(outInfo *)a)._q>(*(outInfo *)b)._q?1:-1; }
//sort in discend order
int comp_z(const void *a,const void *b){ return (*(outInfo *)a)._z>(*(outInfo *)b)._z?-1:1; }

double exp_square(double x)
{  
	return exp(-x*x/2);
}  
double z2p(double lower_boundary,double z_score,double ep=1e-6) 
{  
	double h,s1=0,s2=(z_score-lower_boundary)*(exp_square(lower_boundary)+exp_square(z_score))/2; 
	int n,k;
	for(int n=1;fabs(s1-s2)>ep;n*=2)
	{ 
		h=(z_score-lower_boundary)/n;
		s1 = s2;
		s2 = 0;
		for(int k=0;k<n;++k)
		{
			s2 += h*exp_square(lower_boundary+(k+0.5)*h);
		}
		s2 = (s1+s2)/2;
	}
	return s2*sqrt(1/(8*atan(1.0)));
}  
void getRank(int* rank_table,double* p_table,int num_coeff)
{
	outInfo* oinfo = (outInfo*) malloc (sizeof(outInfo) * num_coeff);
	for(int i=0; i<num_coeff; i++)
	{
		oinfo[i].id=i;
		oinfo[i]._q=p_table[i];
	}
	qsort(oinfo,num_coeff,sizeof(outInfo),comp_q_ascend);
	for(int i=0; i<num_coeff; i++) rank_table[oinfo[i].id]=i+1;
	free(oinfo);
}
PDataBlock::PDataBlock(void)
{
	p_Data=NULL;
	p_Result=NULL;
}

PDataBlock::~PDataBlock(void)
{
	SAFE_DELETE_ARRAY(p_Data);
	SAFE_DELETE_ARRAY(p_Result);
	p_SnpNames.clear();
}

void PDataBlock::readDataBlock(const char* path)
{
	geneInfo* ginfo;
	double* p_Data_tmp;
	vector<string>	p_SnpNames_tmp;
	ifstream in_file;
	in_file.open(path);
	if(!in_file)
	{
		char msg[128]="Unable to open data file\n";
		//sprintf_s(msg,128,"Unable to open %s!\n",path);
		throw(msg);
		return;
	}
	
	char buf[40960];

	p_iSampleNum=0;p_iSnpNum=0;

	if(fabs(remain_para-1.0) <= 1e-6)
	{
		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);
		
			//skip the first line of the data file.
			in_file.getline(buf,40960);		
		
			p_Data=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));		
		
			// row major
			int ptr=0;
			int rawSnpNum=p_iSnpNum;
			for(int i=0;i<rawSnpNum;i++)
			{ 
				string tmpStr, tmpVal;
				vector<double> expVal;
				double rowSum=0.0;
				in_file.getline(buf,40960);			
				istringstream iss(buf);	
				
				iss>>tmpStr;
				for(int j=0;j<p_iSampleNum;j++)
				{
					iss>>tmpVal;					
					rowSum+=fabs(atof(tmpVal.c_str()));
					expVal.push_back(atof(tmpVal.c_str()));
				}
				if(rowSum<=1e-6)
				{
					p_iSnpNum--;
				}
				else
				{
					p_SnpNames.push_back(tmpStr);
					for(int j=0;j<p_iSampleNum;j++)
						p_Data[ptr*p_iSampleNum+j]=expVal[j];
					ptr++;
				}
				
				expVal.clear();
			}
			in_file.close();		
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}

	}
	else{

		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);
		
			//skip the first line of the data file.
			in_file.getline(buf,40960);		
		
			p_Data_tmp=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data_tmp,0,p_iSampleNum*p_iSnpNum*sizeof(double));

			ginfo = (geneInfo*) malloc (sizeof(geneInfo) * p_iSnpNum);
		
			// row major
			for(int i=0;i<p_iSnpNum;i++)
			{ 
				string tmpStr;
				in_file.getline(buf,40960);			
				istringstream iss(buf);			
				iss>>tmpStr;
				strcpy(ginfo[i].gene_name,tmpStr.c_str());
				ginfo[i].gene_id = i;		
				for(int j=0;j<p_iSampleNum;j++){
					iss>>tmpStr;
					p_Data_tmp[i*p_iSampleNum+j]=atof(tmpStr.c_str());			
				}	
			}
			in_file.close();		
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}
		clock_t start=clock();
		//cut off the small mutaion genes, keep the big mutation. THAT IS cut off big entropy and keep the small entropy
		float tmp_sum, tmp_P,tmp_entropy, tmp_tmp;
		#pragma omp parallel for  private(tmp_sum,tmp_P,tmp_entropy,tmp_tmp)
		for(int i=0;i<p_iSnpNum;i++)
		{
			tmp_sum = 0.0;
			tmp_P = 0.0;
			tmp_entropy = 0.0;
			tmp_tmp = 0.0;

			for(int j=0;j<p_iSampleNum;j++)	tmp_sum += fabs(p_Data_tmp[i*p_iSampleNum+j]);
			if(tmp_sum<1E-6){
			//if all the value of this gene is zero, so it is the bad data, should be get rid of.
			//for we will cut off big entropy gene, so we look this row has no mutation, all the value is the same.
			tmp_entropy=log(1.0/p_iSampleNum);
			}
			else
			{
				for(int j=0;j<p_iSampleNum;j++)
				{
					if(fabs(p_Data_tmp[i*p_iSampleNum+j])<1E-6)
					{
						tmp_tmp = 0.0;
					}
					else
					{
						tmp_P = fabs(p_Data_tmp[i*p_iSampleNum+j])/tmp_sum;
						tmp_tmp =  tmp_P*log(tmp_P);
					}
					tmp_entropy += tmp_tmp;
				}
			}
			ginfo[i].gene_entropy = fabs(tmp_entropy);
		}
		qsort(ginfo,p_iSnpNum,sizeof(geneInfo),comp);

		//for(int i=0;i<p_iSnpNum;i++) printf("%d\t%s\t%f\n",ginfo[i].gene_id,ginfo[i].gene_name,ginfo[i].gene_entropy);
		printf("	rowid of the min: %d, min entropy:%f\n",ginfo[0].gene_id,ginfo[0].gene_entropy);
		printf("	rowid of the max: %d,max entropy:%f\n",ginfo[p_iSnpNum-1].gene_id,ginfo[p_iSnpNum-1].gene_entropy);

		
		if(remain_para-1.0>1e-6) p_iSnpNum=p_iSnpNum>ceil(remain_para)?ceil(remain_para):p_iSnpNum;
		else p_iSnpNum = ceil(p_iSnpNum*remain_para);	

		p_Data=new double[p_iSampleNum*p_iSnpNum];
		::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));
	
		for(int i=0;i<p_iSnpNum;i++)
		{
			/*string str(&(ginfo[i].gene_name[0]),&(ginfo[i].gene_name[strlen(ginfo[i].gene_name)]));	*/
			//or
			/*std::string str = &(ginfo[i].gene_name[0]);*/
			//or
			p_SnpNames.push_back(ginfo[i].gene_name);
			/*cout<<p_SnpNames[i]<<endl;	*/
			for(int j=0;j<p_iSampleNum;j++){				
					p_Data[i*p_iSampleNum+j]=p_Data_tmp[ginfo[i].gene_id*p_iSampleNum+j];
			}
		}
		delete(p_Data_tmp);
		free(ginfo);
		
		start=clock()-start;
		printf("	entropy based pre-process: time:%d\n",start);
	}

} 


void PDataBlock::printfResult(const char* path)
{
	FILE *out_file;
	outInfo *oinfo;
	out_file = fopen( path, "wt");
	double tmp;
	oinfo = (outInfo*) malloc (sizeof(outInfo) * p_iSnpNum);

	int num_coeff=p_iSnpNum*(p_iSnpNum-1)/2;		
	double* p_table = (double*) malloc(sizeof(double)*num_coeff);
	memset(p_table,0,num_coeff*sizeof(double));
	double* q_table = (double*) malloc(sizeof(double)*num_coeff);
	memset(q_table,0,num_coeff*sizeof(double));

	if(fdr_para>1e-6)
	{
		#pragma omp parallel for
		for(int i=0;i<num_coeff;i++) p_table[i]=1-(0.5+z2p(0,z_Result[i]));//transform z-score to p-value; one-side test
		int* rank_table = (int*) malloc(sizeof(int)*num_coeff);
		getRank(rank_table,p_table,num_coeff);
		/*unit test*/
		/*for(int i=0;i<20;i++) printf("%f,",p_table[i]);
		printf("\n");
		for(int i=0;i<20;i++) printf("%d,",rank_table[i]);*/
		/*unit test end*/
		for(int i=0;i<num_coeff;i++) q_table[i]=p_table[i]*num_coeff/rank_table[i]; // q-value 
		free(rank_table);
		try{
		
			fprintf(out_file,"Gene1\tGene2\tz-score\tcoeff\tp-value\tq-value\n");	
			for(int i=0;i<p_iSnpNum;i++)
			{			
				for(int j=0;j<i;j++){
					tmp = z_Result[j*(2*p_iSnpNum-j-1)/2+i-j-1];
					oinfo[j].id = j;
					oinfo[j]._z = tmp;
					oinfo[j]._coeff=p_Result[j*(2*p_iSnpNum-j-1)/2+i-j-1];
					oinfo[j]._p = p_table[j*(2*p_iSnpNum-j-1)/2+i-j-1];
					oinfo[j]._q = q_table[j*(2*p_iSnpNum-j-1)/2+i-j-1];
				}
				for(int j=i+1;j<p_iSnpNum;j++)
				{				
					tmp = z_Result[i*(2*p_iSnpNum-i-1)/2+j-i-1];
					oinfo[j].id = j;
					oinfo[j]._z = tmp;	
					oinfo[j]._coeff=p_Result[i*(2*p_iSnpNum-i-1)/2+j-i-1];
					oinfo[j]._p = p_table[i*(2*p_iSnpNum-i-1)/2+j-i-1];
					oinfo[j]._q = q_table[i*(2*p_iSnpNum-i-1)/2+j-i-1];
				}
				oinfo[i].id = i;
				oinfo[i]._z = 0.0;
				oinfo[i]._coeff=0.0;
				oinfo[i]._p = 1.0;
				oinfo[i]._q = 1.0;

				qsort(oinfo,p_iSnpNum,sizeof(outInfo),comp_q_ascend);
				for(int j=0;j<out_count;j++)
				{
					if(fabs(oinfo[j]._q)- fdr_para <= 1E-6)
					{
						fprintf(out_file,"%s\t%s\t%f\t%f\t%f\t%f\n", p_SnpNames[i].c_str(),p_SnpNames[oinfo[j].id].c_str(),oinfo[j]._z,oinfo[j]._coeff,oinfo[j]._p,oinfo[j]._q);	
					}
				}
			}
	}
	catch(...)
	{
		fclose(out_file);
		char msg[128]="Unknown error in opening file, probably illegal input!\n";
		throw(msg);
	}

 }else{
	
	try{
		
		fprintf(out_file,"Gene1\tGene2\tz-score\tcoeff\n");	
		for(int i=0;i<p_iSnpNum;i++)
		{			
			for(int j=0;j<i;j++){
				tmp = z_Result[j*(2*p_iSnpNum-j-1)/2+i-j-1];
				oinfo[j].id = j;
				oinfo[j]._z = tmp;	
				oinfo[j]._coeff=p_Result[j*(2*p_iSnpNum-j-1)/2+i-j-1];
			}
			for(int j=i+1;j<p_iSnpNum;j++)
			{				
				tmp = z_Result[i*(2*p_iSnpNum-i-1)/2+j-i-1];
				oinfo[j].id = j;
				oinfo[j]._z = tmp;	
				oinfo[j]._coeff=p_Result[i*(2*p_iSnpNum-i-1)/2+j-i-1];
			}
			oinfo[i].id = i;
			oinfo[i]._z = 0.0;
			oinfo[i]._coeff=0.0;
			qsort(oinfo,p_iSnpNum,sizeof(outInfo),comp_z);	
			for(int j=0;j<out_count;j++)
			{
				if(fabs(oinfo[j]._z)- critical_val >= 1E-6)
				{
					fprintf(out_file,"%s\t%s\t%f\t%f\n", p_SnpNames[i].c_str(),p_SnpNames[oinfo[j].id].c_str(),oinfo[j]._z,oinfo[j]._coeff);	
				}
			}
		}	
	}
	catch(...)
	{
		fclose(out_file);
		char msg[128]="Unknown error in opening file, probably illegal input!\n";
		throw(msg);
	}
} 
	fclose(out_file);
	free(oinfo);
	free(p_table);
	free(q_table);
}
