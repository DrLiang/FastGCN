To compile:

use Makefile  or Type the command below in terminal:

g++ -m64 -o FastGCN_omp FastGCN.cpp DataBlock.cpp pear_cpu.cpp
