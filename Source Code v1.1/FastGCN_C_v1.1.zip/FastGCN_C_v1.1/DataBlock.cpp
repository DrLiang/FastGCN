#include "DataBlock.h"

#define FILE_CACHE_SIZE 0x80000000 /* = 2GB */
#define FILE_VIEW_SIZE 0x40000000 /* = 1GB */
using namespace std;


int getRowIdx(int tid)
{
	int idx=floor(sqrtf(tid));
	while(1){
		if((idx*(idx+1)/2)>=tid+1) break;
		idx++;
	}
	return idx;
}

//sort in ascend order
int comp(const void *a,const void *b){ return (*(geneInfo *)a).gene_entropy>(*(geneInfo *)b).gene_entropy?1:-1; }
//sort in ascend order
int comp_q_ascend(const void *a,const void *b){ return (*(outInfo *)a)._q>(*(outInfo *)b)._q?1:-1; }
//sort in discend order
int comp_z(const void *a,const void *b){ return (*(outInfo *)a)._z>(*(outInfo *)b)._z?-1:1; }

double exp_square(double x)
{  
	return exp(-x*x/2);
}  
double z2p(double lower_boundary,double z_score,double ep=1e-6) 
{  
	double h,s1=0,s2=(z_score-lower_boundary)*(exp_square(lower_boundary)+exp_square(z_score))/2; 
	int n,k;
	for(int n=1;fabs(s1-s2)>ep;n*=2)
	{ 
		h=(z_score-lower_boundary)/n;
		s1 = s2;
		s2 = 0;
		for(int k=0;k<n;++k)
		{
			s2 += h*exp_square(lower_boundary+(k+0.5)*h);
		}
		s2 = (s1+s2)/2;
	}
	return s2*sqrt(1/(8*atan(1.0)));
}  
void getRank(int* rank_table,double* p_table,int num_coeff)
{
	outInfo* oinfo = (outInfo*) malloc (sizeof(outInfo) * num_coeff);
	for(int i=0; i<num_coeff; i++)
	{
		oinfo[i].id=i;
		oinfo[i]._q=p_table[i];
	}
	qsort(oinfo,num_coeff,sizeof(outInfo),comp_q_ascend);
	for(int i=0; i<num_coeff; i++) rank_table[oinfo[i].id]=i+1;
	free(oinfo);
}
PDataBlock::PDataBlock(void)
{
	p_Data=NULL;
	p_Result=NULL;
}

PDataBlock::~PDataBlock(void)
{
	SAFE_DELETE_ARRAY(p_Data);
	SAFE_DELETE_ARRAY(p_Result);
	p_SnpNames.clear();
}
void PDataBlock::readDataBlock(const char* path)
{
	geneInfo* ginfo;
	double* p_Data_tmp;
	vector<string>	p_SnpNames_tmp;
	ifstream in_file;
	in_file.open(path);
	if(!in_file)
	{
		char msg[128]="Unable to open data file\n";
		//sprintf_s(msg,128,"Unable to open %s!\n",path);
		throw(msg);
		return;
	}
	
	char buf[40960];

	p_iSampleNum=0;p_iSnpNum=0;

	if(fabs(remain_para-1.0) <= 1e-6)
	{
		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);
		
			//skip the first line of the data file.
			in_file.getline(buf,40960);		
		
			p_Data=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));		
		
			// row major
			int ptr=0;
			int rawSnpNum=p_iSnpNum;
			for(int i=0;i<rawSnpNum;i++)
			{ 
				string tmpStr, tmpVal;
				vector<double> expVal;
				double rowSum=0.0;
				in_file.getline(buf,40960);			
				istringstream iss(buf);	
				
				iss>>tmpStr;
				for(int j=0;j<p_iSampleNum;j++)
				{
					iss>>tmpVal;					
					rowSum+=fabs(atof(tmpVal.c_str()));
					expVal.push_back(atof(tmpVal.c_str()));
				}
				if(rowSum<=1e-6)
				{
					p_iSnpNum--;
				}
				else
				{
					p_SnpNames.push_back(tmpStr);
					for(int j=0;j<p_iSampleNum;j++)
						p_Data[ptr*p_iSampleNum+j]=expVal[j];
					ptr++;
				}
				
				expVal.clear();
			}
			in_file.close();		
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}

	}
	else{

		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);
		
			//skip the first line of the data file.
			in_file.getline(buf,40960);		
		
			p_Data_tmp=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data_tmp,0,p_iSampleNum*p_iSnpNum*sizeof(double));

			ginfo = (geneInfo*) malloc (sizeof(geneInfo) * p_iSnpNum);
		
			// row major
			for(int i=0;i<p_iSnpNum;i++)
			{ 
				string tmpStr;
				in_file.getline(buf,40960);			
				istringstream iss(buf);			
				iss>>tmpStr;
				strcpy(ginfo[i].gene_name,tmpStr.c_str());
				ginfo[i].gene_id = i;		
				for(int j=0;j<p_iSampleNum;j++){
					iss>>tmpStr;
					p_Data_tmp[i*p_iSampleNum+j]=atof(tmpStr.c_str());			
				}	
			}
			in_file.close();		
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}
		
		clock_t start=clock();
		//cut off the small mutaion genes, keep the big mutation. THAT IS cut off big entropy and keep the small entropy
		double tmp_sum, tmp_P,tmp_entropy, tmp_tmp;
		for(int i=0;i<p_iSnpNum;i++)
		{
			tmp_sum = 0.0;
			tmp_P = 0.0;
			tmp_entropy = 0.0;
			tmp_tmp = 0.0;

			for(int j=0;j<p_iSampleNum;j++)	tmp_sum += fabs(p_Data_tmp[i*p_iSampleNum+j]);
			if(tmp_sum<1E-6){
			//if all the value of this gene is zero, so it is the bad data, should be get rid of.
			//for we will cut off big entropy gene, so we look this row has no mutation, all the value is the same.
			tmp_entropy=log(1.0/p_iSampleNum);
			}
			else
			{
				for(int j=0;j<p_iSampleNum;j++)
				{
					if(fabs(p_Data_tmp[i*p_iSampleNum+j])<1E-6)
					{
						tmp_tmp = 0.0;
					}
					else
					{
						tmp_P = fabs(p_Data_tmp[i*p_iSampleNum+j])/tmp_sum;
						tmp_tmp =  tmp_P*log(tmp_P);
					}
					tmp_entropy += tmp_tmp;
				}
			}
			ginfo[i].gene_entropy = fabs(tmp_entropy);
		}
		qsort(ginfo,p_iSnpNum,sizeof(geneInfo),comp);

		//for(int i=0;i<p_iSnpNum;i++) printf("%d\t%s\t%f\n",ginfo[i].gene_id,ginfo[i].gene_name,ginfo[i].gene_entropy);
		printf("	rowid of the min: %d, min entropy:%f\n",ginfo[0].gene_id,ginfo[0].gene_entropy);
		printf("	rowid of the max: %d,max entropy:%f\n",ginfo[p_iSnpNum-1].gene_id,ginfo[p_iSnpNum-1].gene_entropy);

		
		if(remain_para-1.0>1e-6) p_iSnpNum=p_iSnpNum>ceil(remain_para)?ceil(remain_para):p_iSnpNum;
		else p_iSnpNum = ceil(p_iSnpNum*remain_para);	

		p_Data=new double[p_iSampleNum*p_iSnpNum];
		::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));
	
		for(int i=0;i<p_iSnpNum;i++)
		{
			/*string str(&(ginfo[i].gene_name[0]),&(ginfo[i].gene_name[strlen(ginfo[i].gene_name)]));	*/
			//or
			/*std::string str = &(ginfo[i].gene_name[0]);*/
			//or
			p_SnpNames.push_back(ginfo[i].gene_name);
			/*cout<<p_SnpNames[i]<<endl;	*/
			for(int j=0;j<p_iSampleNum;j++){				
					p_Data[i*p_iSampleNum+j]=p_Data_tmp[ginfo[i].gene_id*p_iSampleNum+j];
			}
		}
		delete(p_Data_tmp);
		free(ginfo);

		start=clock()-start;
		printf("	entropy based pre-process: time:%d\n",start);
	}

} 
void PDataBlock::readDataBlock_OMimpute(const char* path)
{
	geneInfo* ginfo;
	double* p_Data_tmp;
	vector<string>	p_SnpNames_tmp;
	ifstream in_file;
	in_file.open(path);
	if(!in_file)
	{
		char msg[128]="Unable to open data file\n";
		//sprintf_s(msg,128,"Unable to open %s!\n",path);
		throw(msg);
		return;
	}	
	char buf[40960];
	p_iSampleNum=0;p_iSnpNum=0;
	if(fabs(remain_para-1.0) <= 1e-6)
	{
		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);		
			//skip the first line of the data file.
			in_file.getline(buf,40960);	
			double* p_Data_tmp=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data_tmp,0,p_iSampleNum*p_iSnpNum*sizeof(double));
			// row major
			int ptr=0;
			int rawSnpNum=p_iSnpNum;
			double ttl_sum=0.0;
			int NA_num=0;
			for(int i=0;i<rawSnpNum;i++)
			{ 
				string tmpStr, tmpVal;
				vector<double> expVal;
				double rowSum=0.0;
				in_file.getline(buf,40960);			
				istringstream iss(buf);					
				iss>>tmpStr;
				for(int j=0;j<p_iSampleNum;j++)
				{
					iss>>tmpVal;					
					rowSum+=fabs(atof(tmpVal.c_str()));
					if(strcmp(tmpVal.c_str(),"NA")==0)
					{   
						NA_num++;
						expVal.push_back(-1e6);
					} else expVal.push_back(atof(tmpVal.c_str()));
				}
				if(rowSum<=1e-6)
				{
					p_iSnpNum--;
				}
				else
				{
					ttl_sum+=rowSum;
					p_SnpNames.push_back(tmpStr);
					for(int j=0;j<p_iSampleNum;j++)
						p_Data_tmp[ptr*p_iSampleNum+j]=expVal[j];
					ptr++;
				}			
				expVal.clear();
			}
			 p_Data=new double[p_iSampleNum*p_iSnpNum];
			 ::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));
			clock_t start=clock();
			double overall_mean=ttl_sum/(p_iSnpNum*p_iSampleNum-NA_num);
			// impute with overall mean
			for(int i=0;i<p_iSnpNum;i++)
			{ 		
				for(int j=0;j<p_iSampleNum;j++){
					double tmp=p_Data_tmp[i*p_iSampleNum+j];
					if(abs(tmp+1e6)<1e-6) p_Data[i*p_iSampleNum+j]=overall_mean;
					else p_Data[i*p_iSampleNum+j]= tmp;
				}
			}	
			start=clock()-start;
			printf("	Imputation : time:%d\n",start);
			delete(p_Data_tmp);
			in_file.close();
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}
	}
	else{

		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);
		
			//skip the first line of the data file.
			in_file.getline(buf,40960);			

			p_Data_tmp=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data_tmp,0,p_iSampleNum*p_iSnpNum*sizeof(double));
			ginfo = (geneInfo*) malloc (sizeof(geneInfo) * p_iSnpNum);
			double ttl_sum=0.0;
			int NA_num=0;
			// row major
			for(int i=0;i<p_iSnpNum;i++)
			{ 
				string tmpStr;
				double rowSum=0.0;
				in_file.getline(buf,40960);			
				istringstream iss(buf);			
				iss>>tmpStr;
				strcpy(ginfo[i].gene_name,tmpStr.c_str());
				ginfo[i].gene_id = i;		
				for(int j=0;j<p_iSampleNum;j++){
					iss>>tmpStr;
					rowSum+=fabs(atof(tmpStr.c_str()));
					if(strcmp(tmpStr.c_str(),"NA")==0)
					{   
						NA_num++;
						p_Data_tmp[i*p_iSampleNum+j]=-1e6;
					} else p_Data_tmp[i*p_iSampleNum+j]=atof(tmpStr.c_str());			
				}	
				ttl_sum+=rowSum;
			}
			clock_t start=clock();
			double overall_mean=ttl_sum/(p_iSnpNum*p_iSampleNum-NA_num);
			// impute with overall mean
			for(int i=0;i<p_iSnpNum;i++)
			{ 				
				for(int j=0;j<p_iSampleNum;j++){
					double tmp=p_Data_tmp[i*p_iSampleNum+j];
					if(abs(tmp+1e6)<1e-6) p_Data_tmp[i*p_iSampleNum+j]=overall_mean;					
				}
			}		
			//end of imputation
			start=clock()-start;
			printf("	Imputation : time:%d\n",start);
			in_file.close();		
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}
		
		clock_t start=clock();
		//cut off the small mutaion genes, keep the big mutation. THAT IS cut off big entropy and keep the small entropy
		double tmp_sum, tmp_P,tmp_entropy, tmp_tmp;
		for(int i=0;i<p_iSnpNum;i++)
		{
			tmp_sum = 0.0;
			tmp_P = 0.0;
			tmp_entropy = 0.0;
			tmp_tmp = 0.0;

			for(int j=0;j<p_iSampleNum;j++)	tmp_sum += fabs(p_Data_tmp[i*p_iSampleNum+j]);
			if(tmp_sum<1E-6){
			//if all the value of this gene is zero, so it is the bad data, should be get rid of.
			//for we will cut off big entropy gene, so we look this row has no mutation, all the value is the same.
			tmp_entropy=log(1.0/p_iSampleNum);
			}
			else
			{
				for(int j=0;j<p_iSampleNum;j++)
				{
					if(fabs(p_Data_tmp[i*p_iSampleNum+j])<1E-6)
					{
						tmp_tmp = 0.0;
					}
					else
					{
						tmp_P = fabs(p_Data_tmp[i*p_iSampleNum+j])/tmp_sum;
						tmp_tmp =  tmp_P*log(tmp_P);
					}
					tmp_entropy += tmp_tmp;
				}
			}
			ginfo[i].gene_entropy = fabs(tmp_entropy);
		}
		qsort(ginfo,p_iSnpNum,sizeof(geneInfo),comp);

		//for(int i=0;i<p_iSnpNum;i++) printf("%d\t%s\t%f\n",ginfo[i].gene_id,ginfo[i].gene_name,ginfo[i].gene_entropy);
		printf("	rowid of the min: %d, min entropy:%f\n",ginfo[0].gene_id,ginfo[0].gene_entropy);
		printf("	rowid of the max: %d,max entropy:%f\n",ginfo[p_iSnpNum-1].gene_id,ginfo[p_iSnpNum-1].gene_entropy);

		
		if(remain_para-1.0>1e-6) p_iSnpNum=p_iSnpNum>ceil(remain_para)?ceil(remain_para):p_iSnpNum;
		else p_iSnpNum = ceil(p_iSnpNum*remain_para);	

		p_Data=new double[p_iSampleNum*p_iSnpNum];
		::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));
	
		for(int i=0;i<p_iSnpNum;i++)
		{
			/*string str(&(ginfo[i].gene_name[0]),&(ginfo[i].gene_name[strlen(ginfo[i].gene_name)]));	*/
			//or
			/*std::string str = &(ginfo[i].gene_name[0]);*/
			//or
			p_SnpNames.push_back(ginfo[i].gene_name);
			/*cout<<p_SnpNames[i]<<endl;	*/
			for(int j=0;j<p_iSampleNum;j++){				
					p_Data[i*p_iSampleNum+j]=p_Data_tmp[ginfo[i].gene_id*p_iSampleNum+j];
			}
		}
		delete(p_Data_tmp);
		free(ginfo);

		start=clock()-start;
		printf("	entropy based pre-process: time:%d\n",start);
	}

} 
void PDataBlock::readDataBlock_OMGimpute(const char* path)
{
	geneInfo* ginfo;
	double* p_Data_tmp;
	vector<string>	p_SnpNames_tmp;
	ifstream in_file;
	in_file.open(path);
	if(!in_file)
	{
		char msg[128]="Unable to open data file\n";
		//sprintf_s(msg,128,"Unable to open %s!\n",path);
		throw(msg);
		return;
	}	
	char buf[40960];
	p_iSampleNum=0;p_iSnpNum=0;
	if(fabs(remain_para-1.0) <= 1e-6)
	{
		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);		
			//skip the first line of the data file.
			in_file.getline(buf,40960);	
			double* p_Data_tmp=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data_tmp,0,p_iSampleNum*p_iSnpNum*sizeof(double));
			// row major
			int ptr=0;
			int rawSnpNum=p_iSnpNum;			
			for(int i=0;i<rawSnpNum;i++)
			{ 
				string tmpStr, tmpVal;
				vector<double> expVal;
				double rowSum=0.0;
				double rowMean=0.0;
				int NA_num=0;
				vector<int> missing_id;
				in_file.getline(buf,40960);			
				istringstream iss(buf);					
				iss>>tmpStr;
				for(int j=0;j<p_iSampleNum;j++)
				{
					iss>>tmpVal;					
					rowSum+=fabs(atof(tmpVal.c_str()));
					if(strcmp(tmpVal.c_str(),"NA")==0)
					{   
						NA_num++;
						missing_id.push_back(j);
						expVal.push_back(-1e6);
					} else expVal.push_back(atof(tmpVal.c_str()));
				}
				if(rowSum<=1e-6)
				{
					p_iSnpNum--;
				}
				else
				{
					rowMean=rowSum/(p_iSampleNum-NA_num);
					for(int i=0;i<NA_num;i++) expVal[missing_id[i]]=rowMean; //impute by mean of row.
					p_SnpNames.push_back(tmpStr);
					for(int j=0;j<p_iSampleNum;j++)
						p_Data_tmp[ptr*p_iSampleNum+j]=expVal[j];
					ptr++;
				}			
				expVal.clear();
			}
			 p_Data=new double[p_iSampleNum*p_iSnpNum];
			 ::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));		
			for(int i=0;i<p_iSnpNum;i++)
			{ 		
				for(int j=0;j<p_iSampleNum;j++){
					double tmp=p_Data_tmp[i*p_iSampleNum+j];
					p_Data[i*p_iSampleNum+j]= tmp;
				}
			}	
			
			delete(p_Data_tmp);
			in_file.close();
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}
	}
	else{

		try{
			// get the sample number of the gene. It is the row of the matrix. 
			in_file.getline(buf,40960); // skip the first row. for the first row consists of individual names.
			in_file.getline(buf,40960);		
			for(int i=0;i<in_file.gcount();i++)
			{
				if(*(buf+i) == '	') p_iSampleNum++;
			}		
			// get the gene number. It is the column of the matirx.
			while(!in_file.eof())
			{ 	
				in_file.getline(buf,40960);	
				p_iSnpNum++;
			}
			in_file.clear(ios::goodbit);
			in_file.seekg (0, ios::beg);
		
			//skip the first line of the data file.
			in_file.getline(buf,40960);			

			p_Data_tmp=new double[p_iSampleNum*p_iSnpNum];
			::memset(p_Data_tmp,0,p_iSampleNum*p_iSnpNum*sizeof(double));
			ginfo = (geneInfo*) malloc (sizeof(geneInfo) * p_iSnpNum);			
			
			// row major
			for(int i=0;i<p_iSnpNum;i++)
			{ 
				string tmpStr;
				double rowSum=0.0;
				double rowMean=0.0;
				int NA_num=0;
				vector<int> missing_id;
				in_file.getline(buf,40960);			
				istringstream iss(buf);			
				iss>>tmpStr;
				strcpy(ginfo[i].gene_name,tmpStr.c_str());
				ginfo[i].gene_id = i;		
				for(int j=0;j<p_iSampleNum;j++){
					iss>>tmpStr;
					rowSum+=fabs(atof(tmpStr.c_str()));
					if(strcmp(tmpStr.c_str(),"NA")==0)
					{   
						NA_num++;
						missing_id.push_back(j);
						p_Data_tmp[i*p_iSampleNum+j]=-1e6;
					} else p_Data_tmp[i*p_iSampleNum+j]=atof(tmpStr.c_str());			
				}	
				rowMean=rowSum/(p_iSampleNum-NA_num);
				for(int i=0;i<NA_num;i++) p_Data_tmp[i*p_iSampleNum+missing_id[i]]=rowMean; //impute by mean of row.
			}				
			in_file.close();		
		}
		catch(...)
		{
			in_file.close();
			char msg[128]="Unknown error in opening file, probably illegal input!\n";		
			throw(msg);
		}
		
		clock_t start=clock();
		//cut off the small mutaion genes, keep the big mutation. THAT IS cut off big entropy and keep the small entropy
		double tmp_sum, tmp_P,tmp_entropy, tmp_tmp;
		for(int i=0;i<p_iSnpNum;i++)
		{
			tmp_sum = 0.0;
			tmp_P = 0.0;
			tmp_entropy = 0.0;
			tmp_tmp = 0.0;

			for(int j=0;j<p_iSampleNum;j++)	tmp_sum += fabs(p_Data_tmp[i*p_iSampleNum+j]);
			if(tmp_sum<1E-6){
			//if all the value of this gene is zero, so it is the bad data, should be get rid of.
			//for we will cut off big entropy gene, so we look this row has no mutation, all the value is the same.
			tmp_entropy=log(1.0/p_iSampleNum);
			}
			else
			{
				for(int j=0;j<p_iSampleNum;j++)
				{
					if(fabs(p_Data_tmp[i*p_iSampleNum+j])<1E-6)
					{
						tmp_tmp = 0.0;
					}
					else
					{
						tmp_P = fabs(p_Data_tmp[i*p_iSampleNum+j])/tmp_sum;
						tmp_tmp =  tmp_P*log(tmp_P);
					}
					tmp_entropy += tmp_tmp;
				}
			}
			ginfo[i].gene_entropy = fabs(tmp_entropy);
		}
		qsort(ginfo,p_iSnpNum,sizeof(geneInfo),comp);

		//for(int i=0;i<p_iSnpNum;i++) printf("%d\t%s\t%f\n",ginfo[i].gene_id,ginfo[i].gene_name,ginfo[i].gene_entropy);
		printf("	rowid of the min: %d, min entropy:%f\n",ginfo[0].gene_id,ginfo[0].gene_entropy);
		printf("	rowid of the max: %d,max entropy:%f\n",ginfo[p_iSnpNum-1].gene_id,ginfo[p_iSnpNum-1].gene_entropy);

		
		if(remain_para-1.0>1e-6) p_iSnpNum=p_iSnpNum>ceil(remain_para)?ceil(remain_para):p_iSnpNum;
		else p_iSnpNum = ceil(p_iSnpNum*remain_para);	

		p_Data=new double[p_iSampleNum*p_iSnpNum];
		::memset(p_Data,0,p_iSampleNum*p_iSnpNum*sizeof(double));
	
		for(int i=0;i<p_iSnpNum;i++)
		{
			/*string str(&(ginfo[i].gene_name[0]),&(ginfo[i].gene_name[strlen(ginfo[i].gene_name)]));	*/
			//or
			/*std::string str = &(ginfo[i].gene_name[0]);*/
			//or
			p_SnpNames.push_back(ginfo[i].gene_name);
			/*cout<<p_SnpNames[i]<<endl;	*/
			for(int j=0;j<p_iSampleNum;j++){				
					p_Data[i*p_iSampleNum+j]=p_Data_tmp[ginfo[i].gene_id*p_iSampleNum+j];
			}
		}
		delete(p_Data_tmp);
		free(ginfo);

		start=clock()-start;
		printf("	entropy based pre-process: time:%d\n",start);
	}

} 

void PDataBlock::printfResult(const char* path)
{
	FILE *out_file;
	outInfo *oinfo;
	out_file = fopen( path, "wt");
	double tmp;
	oinfo = (outInfo*) malloc (sizeof(outInfo) * p_iSnpNum);

	int num_coeff=p_iSnpNum*(p_iSnpNum-1)/2;		
	double* p_table = (double*) malloc(sizeof(double)*num_coeff);
	memset(p_table,0,num_coeff*sizeof(double));
	double* q_table = (double*) malloc(sizeof(double)*num_coeff);
	memset(q_table,0,num_coeff*sizeof(double));

	if(fdr_para>1e-6)
	{
		
		for(int i=0;i<num_coeff;i++)
			p_table[i]=1-(0.5+z2p(0,z_Result[i]));//transform z-score to p-value; one-side test
		int* rank_table = (int*) malloc(sizeof(int)*num_coeff);
		getRank(rank_table,p_table,num_coeff);
		/*unit test*/
		/*for(int i=0;i<20;i++) printf("%f,",p_table[i]);
		printf("\n");
		for(int i=0;i<20;i++) printf("%d,",rank_table[i]);*/
		/*unit test end*/
		for(int i=0;i<num_coeff;i++) q_table[i]=p_table[i]*num_coeff/rank_table[i]; // q-value 
		free(rank_table);
		try{
		
			fprintf(out_file,"Gene1\tGene2\tz-score\tcoeff\tp-value\tq-value\n");	
			for(int i=0;i<p_iSnpNum;i++)
			{			
				for(int j=0;j<i;j++){
					tmp = z_Result[i*(i-1)/2+j];
					oinfo[j].id = j;
					oinfo[j]._z = tmp;
					oinfo[j]._coeff=p_Result[i*(i-1)/2+j];
					oinfo[j]._p = p_table[i*(i-1)/2+j];
					oinfo[j]._q = q_table[i*(i-1)/2+j];
				}
				for(int j=i+1;j<p_iSnpNum;j++)
				{				
					tmp = z_Result[j*(j-1)/2+i];
					oinfo[j].id = j;
					oinfo[j]._z = tmp;	
					oinfo[j]._coeff=p_Result[j*(j-1)/2+i];
					oinfo[j]._p = p_table[j*(j-1)/2+i];
					oinfo[j]._q = q_table[j*(j-1)/2+i];
				}
				oinfo[i].id = i;
				oinfo[i]._z = 0.0;
				oinfo[i]._coeff=0.0;
				oinfo[i]._p = 1.0;
				oinfo[i]._q = 1.0;

				qsort(oinfo,p_iSnpNum,sizeof(outInfo),comp_q_ascend);
				for(int j=0;j<out_count;j++)
				{
					if(fabs(oinfo[j]._q)- fdr_para <= 1E-6)
					{
						fprintf(out_file,"%s\t%s\t%f\t%f\t%f\t%f\n", p_SnpNames[i].c_str(),p_SnpNames[oinfo[j].id].c_str(),oinfo[j]._z,oinfo[j]._coeff,oinfo[j]._p,oinfo[j]._q);	
					}
				}
			}
	}
	catch(...)
	{
		fclose(out_file);
		char msg[128]="Unknown error in opening file, probably illegal input!\n";
		throw(msg);
	}

 }else{
	
	try{
		
		fprintf(out_file,"Gene1\tGene2\tz-score\tcoeff\n");	
		for(int i=0;i<p_iSnpNum;i++)
		{			
			for(int j=0;j<i;j++){
				tmp = z_Result[i*(i-1)/2+j];
				oinfo[j].id = j;
				oinfo[j]._z = tmp;	
				oinfo[j]._coeff=p_Result[i*(i-1)/2+j];
			}
			for(int j=i+1;j<p_iSnpNum;j++)
			{				
				tmp = z_Result[j*(j-1)/2+i];
				oinfo[j].id = j;
				oinfo[j]._z = tmp;	
				oinfo[j]._coeff=p_Result[j*(j-1)/2+i];
			}
			oinfo[i].id = i;
			oinfo[i]._z = 0.0;
			oinfo[i]._coeff=0.0;
			qsort(oinfo,p_iSnpNum,sizeof(outInfo),comp_z);	
			for(int j=0;j<out_count;j++)
			{
				if(fabs(oinfo[j]._z)- critical_val >= 1E-6)
				{
					fprintf(out_file,"%s\t%s\t%f\t%f\n", p_SnpNames[i].c_str(),p_SnpNames[oinfo[j].id].c_str(),oinfo[j]._z,oinfo[j]._coeff);	
				}
			}
		}	
	}
	catch(...)
	{
		fclose(out_file);
		char msg[128]="Unknown error in opening file, probably illegal input!\n";
		throw(msg);
	}
} 
	fclose(out_file);
	free(oinfo);
	free(p_table);
	free(q_table);
}

void PDataBlock::modlsIndt()
{
	
	
	/***method3***/
	int z_num=p_iSnpNum*(p_iSnpNum-1)/2;
	smlrtyMat=(double*) malloc(sizeof(double)*z_num);
	memset(smlrtyMat,0,z_num*sizeof(double));

	int* adjaMat = (int*) malloc(sizeof(int)*z_num);
	memset(adjaMat,0,z_num*sizeof(int));	
	int* Kvec = (int*) malloc(sizeof(int)*p_iSnpNum);
	memset(Kvec,0,p_iSnpNum*sizeof(int));
	
	int adj_num=0;
	//preallcoate z_num memory unit 
	int* rowIds=(int*) malloc(sizeof(int)*z_num);
	int* colIds=(int*) malloc(sizeof(int)*z_num);
	int* i_store=(int*) malloc(sizeof(int)*z_num);
	memset(i_store,0,z_num*sizeof(int));
	memset(rowIds,0,z_num*sizeof(int));
	memset(colIds,0,z_num*sizeof(int));
	for(int i=0;i<z_num;i++)
	{
		if(z_Result[i]>=critical_val)
		{
			int rd=getRowIdx(i);
			int cd=i-rd*(rd-1)/2;
			rowIds[adj_num]=rd;
			colIds[adj_num]=cd;
			i_store[adj_num]=i;
			adjaMat[i]=1;
			Kvec[rd]++;
			Kvec[cd]++;
			adj_num++;
		}
	}
	int unzero_num=adj_num;
	for(int i=0;i<adj_num;i++)
	{
		for(int j=i+1;j<adj_num;j++)
		{
			if(rowIds[i]==colIds[j])
			{
				int id=rowIds[j]*(rowIds[j]-1)/2+colIds[i];
				if(adjaMat[id]++==0)
				{
					i_store[unzero_num]=id;
					unzero_num++;
				}
				// we got h + adja here 
			}
		}
	}
	
	for(int i=0;i<unzero_num;i++)
	{
		int id=i_store[i];
		int rd=getRowIdx(id);
		int cd=id-rd*(rd-1)/2;
		double tmp=adjaMat[id]*1.0;
		smlrtyMat[id]=tmp/(Kvec[rd]+Kvec[cd]-tmp);
	}
	
	free(adjaMat);
	free(rowIds);
	free(colIds);
	free(Kvec);
	free(i_store);
	/*************/

	/***method2*****/
	// only store the index of the value of 1
	//int z_num=p_iSnpNum*(p_iSnpNum-1)/2;
	//smlrtyMat=(double*) malloc(sizeof(double)*z_num);
	//memset(smlrtyMat,0,z_num*sizeof(double));
	//int* adjaMat = (int*) malloc(sizeof(int)*z_num);
	//memset(adjaMat,0,z_num*sizeof(int));
	//
	//int* Kvec = (int*) malloc(sizeof(int)*p_iSnpNum);
	//memset(Kvec,0,p_iSnpNum*sizeof(int));
	//
	//int adj_num=0;
	////preallcoate z_num memory unit 
	//int* rowIds=(int*) malloc(sizeof(int)*z_num);
	//int* colIds=(int*) malloc(sizeof(int)*z_num);
	//memset(rowIds,0,z_num*sizeof(int));
	//memset(colIds,0,z_num*sizeof(int));
	//for(int i=0;i<z_num;i++)
	//{
	//	if(p_Result[i]>=critical_val)
	//	{
	//		int rd=getRowIdx(i);
	//		int cd=i-rd*(rd-1)/2;
	//		rowIds[adj_num]=rd;
	//		colIds[adj_num]=cd;
	//		adjaMat[i]=1;
	//		Kvec[rd]++;
	//		Kvec[cd]++;
	//		adj_num++;
	//	}
	//}

	//for(int i=0;i<adj_num;i++)
	//{
	//	for(int j=i+1;j<adj_num;j++)
	//	{
	//		if(rowIds[i]==colIds[j]) smlrtyMat[rowIds[j]*(rowIds[j]-1)/2+colIds[i]]+=1.0;
	//	}
	//}
	//for(int i=0;i<z_num;i++)
	//{
	//	int rd=getRowIdx(i);
	//	int cd=i-rd*(rd-1)/2;
	//	double tmp=smlrtyMat[i]+adjaMat[i];
	//	smlrtyMat[i]=tmp/(Kvec[rd]+Kvec[cd]-tmp);
	//}
	//free(adjaMat);
	//free(rowIds);
	//free(colIds);
	//free(Kvec);
	/****************/

	/*****method1****/	
	/*
	smlrtyMat=(double*) malloc(sizeof(double)*p_iSnpNum*p_iSnpNum);
	memset(smlrtyMat,0,p_iSnpNum*p_iSnpNum*sizeof(double));
	double* adjaMat = (double*) malloc(sizeof(double)*p_iSnpNum*p_iSnpNum);
	memset(adjaMat,0,p_iSnpNum*p_iSnpNum*sizeof(double));
	
	int* Kvec = (int*) malloc(sizeof(int)*p_iSnpNum);
	memset(Kvec,0,p_iSnpNum*sizeof(int));
	// get adjacency matrix and node connectivity vector
	
	for(int i=0;i<p_iSnpNum;i++)
	{
		double tmp;
		for(int j=0;j<i;j++)
		{
			tmp = p_Result[i*(i-1)/2+j];
			if(tmp>=critical_val)
			{
				adjaMat[i*p_iSnpNum+j]=1;
				Kvec[i]++;
			}
		}
		for(int j=i+1;j<p_iSnpNum;j++)
		{
			tmp = p_Result[j*(j-1)/2+i];
			if(tmp>=critical_val)
			{
				adjaMat[i*p_iSnpNum+j]=1; 
				Kvec[i]++;
			}
		}
	}
	// get h matrix stored in smlrtyMat temporarily
	for(int i=0;i<p_iSnpNum;i++)
		for(int j=0;j<p_iSnpNum;j++)
			for(int k=0;k<p_iSnpNum;k++) smlrtyMat[i*p_iSnpNum+j]=adjaMat[i*p_iSnpNum+k]*adjaMat[j*p_iSnpNum+k];

	for(int i=0;i<p_iSnpNum;i++) smlrtyMat[i*p_iSnpNum+i]=0;
	// get the similarity matrix
	for(int i=0;i<p_iSnpNum;i++)
		for(int j=0;j<p_iSnpNum;j++) smlrtyMat[i*p_iSnpNum+j]=(smlrtyMat[i*p_iSnpNum+j]+adjaMat[i*p_iSnpNum+j])/(Kvec[i]+Kvec[j]-smlrtyMat[i*p_iSnpNum+j]-adjaMat[i*p_iSnpNum+j]);

	free(adjaMat);
	free(Kvec);
	*/
	/*******/
}