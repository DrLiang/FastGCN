#include "DataBlock.h"

using namespace std;

char inputPath[512];
char outputPath[512];
double threshold;
double   remain_para;
double fdr_para=-1.0;
int     _out_count;
//============================================

extern "C"
void singleCpuProc(gpuArgs* g_Params);

//============================================

int main(int argc, char *argv[]) 
{	
	
	cout<<"**************************************************************************"<<endl;
	cout<<"      FastGCN (a GPU accelerated tool for Fast Gene Co-expression Networks) 0.99"<<endl;
	cout<<"      Copyright (c) 2010-2014 by Meimei Liang, Futao Zhang, Gulei Jin and Jun Zhu"<<endl;
	cout<<"      Institute of Bioinformatics, Zhejiang University, China"<<endl;
	cout<<"      First use Information Entropy to pretreat and cut off some genes."<<endl; 
	cout<<"      Then calculate the Pairwise Correlation Coefficients."<<endl; 
	cout<<"      Finally do Z-normalization of the coefficients"<<endl;
	cout<<"      You should input 2, 3, 4, 5 or 6 arguments, the first one is the input file name"<<endl; 
	cout<<"      and the second is the output file name! The 3rd, 4th, 5th 6th are optional. "<<endl; 
	cout<<"      The 3rd is the threshold of z-score for output, default as 3.29 . "<<endl; 
	cout<<"      The 4th is the  parameter for data preprocessing, default as 1. "<<endl; 
	cout<<"      That means all the raw data will be kept."<<endl; 
	cout<<" 	 If the parameter is a double number falling into an open interval (0,1),"<<endl;
	cout<<"      that means the proportion will be kept."<<endl; 
	cout<<" 	 If the parameter is a integer number falling into an open interval (1,infinite),"<<endl;
	cout<<"      that means that number of genes will be kept. "<<endl;
	cout<<"      The 5th is the maximum output count number, default as 100 per gene."<<endl;
	cout<<"      That means the first maximum count number per gene to be output."<<endl;
	cout<<"      The 6th is FDR control parameter, default as being disabled."<<endl;
	cout<<"      That means using z-score threshold."<<endl;
	cout<<"      When this parameter is enabled and set a value, the 3rd parameter is disabled. "<<endl; 
	cout<<"**************************************************************************"<<endl;

	if (argc < 3) {
        fprintf(stderr, "Input argument error, at least 2 are needed.\n");
        exit(1);
    }    
    strcpy(inputPath, argv[1]);
	strcpy(outputPath, argv[2]);

	if (argc>=4) threshold = atof(argv[3]);
	else threshold = 3.29;
	if (argc>=5) remain_para = atof(argv[4]);
	else remain_para = 1.0;
	if (argc>=6) _out_count = atoi(argv[5]);
	else _out_count = 100;
	if (argc>=7) fdr_para = atof(argv[6]);

	clock_t start=clock();

	// read data from the data file.
	PDataBlock dataBlock;
	dataBlock.remain_para = remain_para;
	dataBlock.readDataBlock_OMGimpute(inputPath);
	
	
	if (_out_count>dataBlock.p_iSnpNum) _out_count = dataBlock.p_iSnpNum;

    //printf("Gene Number:%d,column Numer:%d,threshold:%f\n",dataBlock.p_iSnpNum,dataBlock.p_iSampleNum,threshold);
	printf("	Gene Number after cut-off:%d,column Numer:%d\n",dataBlock.p_iSnpNum,dataBlock.p_iSampleNum);

	start=clock()-start;
	printf("	Input Process: time:%d\n",start);
	
	//init the gpu parameter5s	
	gpuArgs g_Params;	
	g_Params.geneNum = dataBlock.p_iSnpNum;
	g_Params.geneValNum = dataBlock.p_iSampleNum;	
	g_Params.p_Data = dataBlock.p_Data;	
	
	g_Params.pearTable = new double[g_Params.geneNum*(g_Params.geneNum-1)/2];
	::memset(g_Params.pearTable,0,g_Params.geneNum*(g_Params.geneNum-1)*sizeof(double)/2);
	g_Params.zTable = new double[g_Params.geneNum*(g_Params.geneNum-1)/2];
	::memset(g_Params.zTable,0,g_Params.geneNum*(g_Params.geneNum-1)*sizeof(double)/2);	
	

	start=clock();

	// call  funtion
	singleCpuProc(&g_Params);

	start=clock()-start;
	printf("	Computing Process: time:%d\n",start);

	start=clock();

	dataBlock.p_Result = g_Params.pearTable;
	dataBlock.z_Result = g_Params.zTable;
	dataBlock.critical_val = threshold;	
	dataBlock.fdr_para = fdr_para;	
	dataBlock.out_count = _out_count;
	dataBlock.modlsIndt();

	start=clock()-start;
	printf("	Module Identification: time:%d\n",start);

	start=clock();

	dataBlock.printfResult(outputPath);	
	
	start=clock()-start;
	printf("	Output Process: time:%d\n",start);
	return 0;
}
