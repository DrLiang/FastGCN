#include "DataBlock.h"
#include <omp.h>
#ifndef GENERALTYPE_H
	#include "generalType.h"
#endif

using namespace std;

int bsearch(vector<int>	g_sampleNum, int target)
{
    int mid;
	int left=0;
	int right= g_sampleNum.size()-1;
	while (left < right)
    {		
		mid = (left+right)/2;
        if (g_sampleNum[mid] == target) return mid;
        else if (g_sampleNum[mid] > target) right=mid;
        else left=mid+1;
    }
    return mid;
}

int ssearch(vector<int>	g_sampleNum, int target)
{
	int i;
	for( i=0;i<g_sampleNum.size();i++){
		if(g_sampleNum[i] == target) return i;
		else if (g_sampleNum[i] > target) break;
	}
    return i-1;
}


extern "C"
void singleCpuProc(gpuArgs* g_Params){

    int row = g_Params->geneNum;
	int col = g_Params->geneValNum;
	
	double* tmpX=new double[row];
	double* tmpX2=new double[row];	
	::memset(tmpX,0,row*sizeof(double));		
	::memset(tmpX2,0,row*sizeof(double));
//
//	int Num_CPU_Cores;
//#ifdef WIN32 
//		SYSTEM_INFO si;
//		GetSystemInfo(&si);
//		Num_CPU_Cores=si.dwNumberOfProcessors;		
//#elif
//		Num_CPU_Cores=sysconf(_SC_NPROCESSORS_CONF);
//#endif
//	omp_set_num_threads(Num_CPU_Cores);
//	
	#pragma omp parallel for
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			tmpX[i] += g_Params->p_Data[i*col+j];
			tmpX2[i] += g_Params->p_Data[i*col+j]*g_Params->p_Data[i*col+j];
		}
	}	
	double tmp0;
	// use lower triangular, because of i>j
	#pragma omp parallel for private(tmp0)
	for(int i=0;i<row;i++){
		for(int j=0;j<i;j++){
			tmp0=0;			
			for(int k=0;k<col;k++) tmp0 += g_Params->p_Data[i*col+k]*g_Params->p_Data[j*col+k];	
			g_Params->pearTable[i*(i-1)/2+j] = 
				(tmp0-tmpX[i]*tmpX[j]/col)/sqrtf((tmpX2[i]-tmpX[i]*tmpX[i]/col)*(tmpX2[j]-tmpX[j]*tmpX[j]/col));
				
		}
	}
	// Z standardization
	// Z= (x-x_mean)/S   S is the Standard Deviation
	// S = sqrt( ( (x0-x_mean)^2+(x1-x_mean)^2+...+(xn-x_mean)^2 )/(n-1) )
	int _n = row*(row-1)/2;
	double _sum=0.0, _mean=0.0, _S=0.0;
	for(int i=0;i<_n;i++) _sum+= fabs(g_Params->pearTable[i]);
	_mean = _sum/_n;
    for(int i=0;i<_n;i++)
	{
		double tmp1=fabs(g_Params->pearTable[i]) - _mean;
		_S=_S+tmp1*tmp1;
	}
	_S = sqrt(_S/(_n-1));
	for(int i=0;i<_n;i++) g_Params->zTable[i] = (fabs(g_Params->pearTable[i]) - _mean)/_S;

	double max=0.0;
	for(int i=0;i<_n;i++){
		if(g_Params->zTable[i]-max>1E-6) max=g_Params->zTable[i];
	}
	
	printf("	the max z-score is: %f\n",max);

	delete(tmpX);
	delete(tmpX2);	
	
}
