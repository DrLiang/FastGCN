#ifndef GENERALTYPE_H
#define GENERALTYPE_H

#include <vector>
#include <fstream> 
#include <string.h>
#include <time.h>
#include <iostream>
#include <sstream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define SAFE_DELETE(p) if(p){delete p;p=NULL;}
#define SAFE_DELETE_ARRAY(p) if(p){delete[] p;p=NULL;}

#define SAFE_RELEASE(p) if(p){p->Release();p=NULL;}


#define THREAD_NUM_COUNT	256
#define BLOCK_SIZE	64


#define THRESHOLD_DRAW	1e-3
#define THRESHOLD1	1e-6
#define THRESHOLD2	1e-8

using namespace std;

struct gpuArgs{
	
	int		geneNum;	
	int		splNum;
	float	remain_para;
	vector<string>	geneNames;
	float*	p_Data;	
	float*	pearTable;
	float* pcc_coeff;

};

struct geneInfo{
	int gene_id;
	//char gene_name[128];	
	float gene_entropy;
};

struct outInfo{
	int id;
	float _coeff;
	float _p;
	float _z;//z-scor 
	float _q;//q-value
};
#endif
