#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// CUDA-C includes
#include <cuda.h>
#include <cuda_runtime.h>

#include <helper_cuda.h>


#include "checkGPU.h"

size_t getFreeMemory(){
	
	size_t freeMem,totalMem;
	cudaError_t res;	
	res= cudaMemGetInfo (&freeMem,&totalMem);
	if(res!=cudaSuccess)
		printf("cuMemGetInfo failed!(status=%x)",res);	
	
	return freeMem;
	
}


int getGPUnum(){
	int deviceCount=0;	
	int cudaDevCount=0;
	/*********modified by futoaz 101028**********************/
	if (cudaGetDeviceCount(&deviceCount) == cudaSuccess) {
		int dev;
		for (dev = 0; dev < deviceCount; ++dev) {
			cudaDeviceProp deviceProp;
			cudaGetDeviceProperties(&deviceProp, dev);
			if (dev == 0) {		
				if (deviceProp.major == 9999 && deviceProp.minor == 9999); 
				else if (deviceCount == 1)	cudaDevCount=1;
				else	cudaDevCount=deviceCount;		
			}	
		}	
	}
	return cudaDevCount;
}

void ckEnv(){

	int deviceCount=0;
	
	int cudaDevCount=0;
	if (cudaGetDeviceCount(&deviceCount) == cudaSuccess) {
		int dev;
		//get CUDA device number
		for (dev = 0; dev < deviceCount; ++dev) {
			cudaDeviceProp deviceProp;
			cudaGetDeviceProperties(&deviceProp, dev);
			if (dev == 0) {	
				if (deviceProp.major == 9999 && deviceProp.minor == 9999);   
				else if (deviceCount == 1)	cudaDevCount=1;
				else	cudaDevCount=deviceCount;	
			}
		}
		// 
		if(cudaDevCount>1){
			printf("  Using Multi-GPU!\n");
			for (dev = 0; dev < cudaDevCount; ++dev) {
				cudaDeviceProp deviceProp;
				cudaGetDeviceProperties(&deviceProp, dev);
				printf("  Device%d:%s with %dMB total memory.\n",dev,deviceProp.name,deviceProp.totalGlobalMem/1024/1024);
		}
		}else if(cudaDevCount==1){
			printf("  Using GPU!\n");
			cudaDeviceProp deviceProp;
			cudaGetDeviceProperties(&deviceProp, 0);
			printf("  Device0:%s with %dMB total memory.\n",deviceProp.name,deviceProp.totalGlobalMem/1024/1024);
		}else{
			
			/*********modified by futoaz 101028**********************/
			printf("  There are no device supporting CUDA, program is running on CPU!");
			
			/*******************************************************/
		}	
	}else exit(1);
}